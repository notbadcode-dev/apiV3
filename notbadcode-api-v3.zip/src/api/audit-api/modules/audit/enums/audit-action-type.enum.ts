export enum EAuditActionType {
  CREATE = 'CREATE',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  ACTION = 'ACTION',
  OTHERS = 'OTHERS',
}
