export enum EAuthenticationType {
  LOGIN = 'login',
  REGISTRATION = 'registration',
}
