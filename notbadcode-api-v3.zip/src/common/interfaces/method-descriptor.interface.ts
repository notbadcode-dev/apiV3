export interface IMethodDescriptor {
  value: (...args: unknown[]) => unknown;
}
