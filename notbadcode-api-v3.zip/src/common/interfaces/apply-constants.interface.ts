export interface IApplyConstantsFunction<P, R> {
  apply: (applyParameter: P) => R;
}
