export enum EMessageType {
  INFORMATION = 'Information',
  SUCCESSFULLY = 'Successfully',
  WARNING = 'Warning',
  DANGER = 'Danger',
  CRITICAL = 'Critical',
}
