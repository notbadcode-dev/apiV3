export const TOKEN_CONSTANTS = {
  tokenExpiredErrorTag: 'TokenExpiredError',

  messages: {
    previousTokenNotFound: 'Previous token not found.',
  },
};
