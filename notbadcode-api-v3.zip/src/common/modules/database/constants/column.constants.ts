export const COLUMN_CONSTANTS = {
  currentTimeStamp: 'CURRENT_TIMESTAMP',

  isActiveDefaultValue: true,
};
