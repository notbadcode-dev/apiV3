export const MESSAGE_CONSTANTS = {
  maxLengthMessage: 200,
};
