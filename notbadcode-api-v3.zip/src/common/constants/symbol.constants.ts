export const SYMBOL_CONSTANTS = {
  comma: ',',
};
